Change Log :

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0
