(function($){
	
	"use strict";

	function do_toggle()
	{
		$("h3.toggle-head-open").click(function() 
		{
			$(this).parent().find("div.toggle-content").slideToggle("slow");
			$(this).hide();
			$(this).parent().find("h3.toggle-head-close").show();
	    });

		$("h3.toggle-head-close").click(function () {
			$(this).parent().find("div.toggle-content").slideToggle("slow");
			$(this).hide();
			$(this).parent().find("h3.toggle-head-open").show();
	    });
	}

	function do_tooltip()
	{
		$('.tooltip').tipsy({fade: true, gravity: 's'});
		$('.tooltip-nw').tipsy({fade: true, gravity: 'nw'});
	    $('.tooltip-ne').tipsy({fade: true, gravity: 'ne'});
	    $('.tooltip-w' ).tipsy({fade: true, gravity: 'w' });
	    $('.tooltip-e' ).tipsy({fade: true, gravity: 'e' });
	    $('.tooltip-sw').tipsy({fade: true, gravity: 'w' });
	    $('.tooltip-se').tipsy({fade: true, gravity: 'e' });
	    $('.ttip, .tooltip-n').tipsy({fade: true, gravity: 's'});
	    $('.tooldown, .tooltip-s').tipsy({fade: true, gravity: 'n'});
	}

	function do_lightbox()
	{
		var $post = $('.entry-content');

		$("a.lightbox-enabled, a[rel='lightbox-enabled']").iLightBox({ skin: jnewsmigration.lightbox_skin } );

		if ( jnewsmigration.lightbox_all )
		{
		 	$post.find("div.entry a").not("div.entry .gallery a").each(function(i, el) 
		 	{
				var href_value = el.href;
				if (/\.(jpg|jpeg|png|gif)$/.test(href_value)) {
					$(this).iLightBox( { skin: jnewsmigration.lightbox_skin} );
				}
			});
		};

		if ( jnewsmigration.lightbox_gallery )
		{
			$post.find("div.entry .gallery a").each(function(i, el) 
			{
				var href_value = el.href;
				if (/\.(jpg|jpeg|png|gif)$/.test(href_value)) {
					$(this).addClass('ilightbox-gallery');
				}
			});

			$post.find('.ilightbox-gallery').iLightBox(
			{
				skin: jnewsmigration.lightbox_skin,
				path: jnewsmigration.lightbox_thumb,
				controls: {
					arrows: jnewsmigration.lightbox_arrows,
				}
			});
		};

		$('section.videos-lightbox a.single-videolighbox').iLightBox({
			skin: jnewsmigration.lightbox_skin,
			path: jnewsmigration.lightbox_thumb,
			controls: {
				arrows: jnewsmigration.lightbox_arrows,
			}
		});

		if ( jnewsmigration.woocommerce_lightbox == 'yes' )
		{
			$( "a[rel='lightbox-enabled[product-gallery]']" ).iLightBox({
				skin: jnewsmigration.lightbox_skin,
				path: jnewsmigration.lightbox_thumb,
				controls: {
					arrows: jnewsmigration.lightbox_arrows,
				}
			});
		};

		$('.content-inner a').magnificPopup(
		{
			disableOn: function() 
			{
				if( $(this).hasClass('lightbox-enabled') ) 
				{
				    return true;
				}
				return false;
			}
		});
	}

	function dispatch()
	{
		do_toggle();
		do_tooltip();
		do_lightbox();
	}

	$(document).ready( dispatch );

})(jQuery);